const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const multer = require('multer');
const xlsx = require('xlsx');
const ExcelJS = require('exceljs');
const fs = require('fs');
const config = require('./config');

// Configurar servidor Express
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(express.static('public'));

// Configurar multer para upload de arquivos
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Armazenamento em memória (simulando banco de dados)
const db = {
  clientes: {},
  agendamentos: {},
  prospeccoes: {},
  sincronizacao: []
};

// Diretório de dados
const dataDir = path.join(__dirname, config.storage.dataDir);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Diretório de logs
const logDir = path.dirname(config.logging.file);
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// Função de log
function log(level, message, data = null) {
  const levels = ['debug', 'info', 'warn', 'error'];
  const configLevel = config.logging.level;
  
  if (levels.indexOf(level) >= levels.indexOf(configLevel)) {
    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp} [${level.toUpperCase()}] ${message}`;
    
    console.log(logMessage);
    
    if (data) {
      console.log(data);
    }
    
    // Gravar no arquivo de log
    try {
      fs.appendFileSync(
        config.logging.file,
        logMessage + (data ? ' ' + JSON.stringify(data) : '') + '\n'
      );
    } catch (error) {
      console.error('Erro ao gravar log:', error);
    }
  }
}

// Carregar dados do arquivo se existir
function carregarDados() {
  try {
    // Verificar se os arquivos existem
    const clientesPath = path.join(dataDir, 'clientes.json');
    const agendamentosPath = path.join(dataDir, 'agendamentos.json');
    const prospeccoesPath = path.join(dataDir, 'prospeccoes.json');
    
    if (fs.existsSync(clientesPath)) {
      db.clientes = JSON.parse(fs.readFileSync(clientesPath, 'utf8'));
      log('info', `Carregados ${Object.keys(db.clientes).length} clientes`);
    }
    
    if (fs.existsSync(agendamentosPath)) {
      db.agendamentos = JSON.parse(fs.readFileSync(agendamentosPath, 'utf8'));
      log('info', `Carregados ${Object.keys(db.agendamentos).length} agendamentos`);
    }
    
    if (fs.existsSync(prospeccoesPath)) {
      db.prospeccoes = JSON.parse(fs.readFileSync(prospeccoesPath, 'utf8'));
      log('info', `Carregadas ${Object.keys(db.prospeccoes).length} prospecções`);
    }
  } catch (error) {
    log('error', 'Erro ao carregar dados:', error);
  }
}

// Salvar dados em arquivo
function salvarDados() {
  try {
    // Salvar clientes
    fs.writeFileSync(
      path.join(dataDir, 'clientes.json'),
      JSON.stringify(db.clientes, null, 2)
    );
    
    // Salvar agendamentos
    fs.writeFileSync(
      path.join(dataDir, 'agendamentos.json'),
      JSON.stringify(db.agendamentos, null, 2)
    );
    
    // Salvar prospecções
    fs.writeFileSync(
      path.join(dataDir, 'prospeccoes.json'),
      JSON.stringify(db.prospeccoes, null, 2)
    );
    
    log('info', 'Dados salvos com sucesso');
  } catch (error) {
    log('error', 'Erro ao salvar dados:', error);
  }
}

// Configurar salvamento automático
setInterval(salvarDados, config.storage.autoSaveInterval);

// Carregar dados iniciais
carregarDados();

// Rotas da API

// Rota para verificar status do servidor
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    sincronizacao: 'ativa',
    version: '1.0.0'
  });
});

// Rota para obter todos os clientes
app.get('/api/clientes', (req, res) => {
  res.json(db.clientes);
});

// Rota para obter todos os agendamentos
app.get('/api/agendamentos', (req, res) => {
  res.json(db.agendamentos);
});

// Rota para obter todas as prospecções
app.get('/api/prospeccoes', (req, res) => {
  res.json(db.prospeccoes);
});

// Rota para salvar uma prospecção
app.post('/api/prospeccoes', (req, res) => {
  try {
    const { prospeccao, dispositivo } = req.body;
    
    if (!prospeccao || !prospeccao.id_cliente) {
      return res.status(400).json({ error: 'Dados de prospecção inválidos' });
    }
    
    // Adicionar timestamp e informações do dispositivo
    prospeccao.dataSalvamento = new Date().toISOString();
    prospeccao.dispositivo = dispositivo || 'desconhecido';
    
    // Salvar prospecção no banco de dados
    db.prospeccoes[prospeccao.id_cliente] = prospeccao;
    
    // Registrar operação de sincronização
    db.sincronizacao.push({
      timestamp: prospeccao.dataSalvamento,
      dispositivo: dispositivo || 'desconhecido',
      operacao: 'salvar',
      tabela: 'prospeccoes',
      registro_id: prospeccao.id_cliente
    });
    
    // Limitar tamanho do array de sincronização
    if (db.sincronizacao.length > 1000) {
      db.sincronizacao = db.sincronizacao.slice(-1000);
    }
    
    log('info', 'Prospecção salva', { id_cliente: prospeccao.id_cliente, dispositivo });
    
    res.json({ 
      success: true, 
      message: 'Dados salvos e sincronizados com sucesso',
      timestamp: prospeccao.dataSalvamento
    });
  } catch (error) {
    log('error', 'Erro ao salvar prospecção:', error);
    res.status(500).json({ error: 'Erro ao salvar prospecção' });
  }
});

// Rota para importar clientes de arquivo Excel
app.post('/api/importar/excel', upload.single('arquivo'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado' });
    }
    
    // Ler arquivo Excel
    const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const dados = xlsx.utils.sheet_to_json(worksheet);
    
    if (!dados || dados.length === 0) {
      return res.status(400).json({ error: 'Arquivo Excel vazio ou inválido' });
    }
    
    log('info', `Importando ${dados.length} clientes do Excel`);
    
    // Processar clientes
    const clientes = dados.map((row, index) => {
      return {
        id_cliente: `cliente_${Date.now()}_${index + 1}`,
        nome: row.Nome || row.NOME || row.nome || '',
        empresa: row.Empresa || row.EMPRESA || row.empresa || '',
        telefone: row.Telefone || row.TELEFONE || row.telefone || '',
        email: row.Email || row.EMAIL || row.email || '',
        cnpj: row.CNPJ || row.cnpj || '',
        cidade: row.Cidade || row.CIDADE || row.cidade || '',
        estado: row.Estado || row.ESTADO || row.estado || '',
        segmento: row.Segmento || row.SEGMENTO || row.segmento || '',
        data_importacao: new Date().toISOString()
      };
    });
    
    // Dividir clientes entre vendedores e criar agendamentos
    const totalClientes = clientes.length;
    const clientesVendedor1 = clientes.slice(0, Math.ceil(totalClientes / 2));
    const clientesVendedor2 = clientes.slice(Math.ceil(totalClientes / 2));
    
    // Criar agendamentos
    const agendamentos = [];
    const diasSemana = ['segunda', 'terca', 'quarta', 'quinta', 'sexta'];
    const periodos = ['manha', 'tarde'];
    
    // Função para criar agendamentos para um vendedor
    const criarAgendamentos = (clientesVendedor, vendedor) => {
      let clienteIndex = 0;
      
      for (const dia of diasSemana) {
        for (const periodo of periodos) {
          // 5 clientes por período
          for (let i = 0; i < 5; i++) {
            if (clienteIndex < clientesVendedor.length) {
              const cliente = clientesVendedor[clienteIndex];
              
              agendamentos.push({
                id_agendamento: `${vendedor}_${dia}_${periodo}_${i + 1}`,
                id_cliente: cliente.id_cliente,
                vendedor: vendedor,
                dia_semana: dia,
                periodo: periodo,
                ordem: i + 1,
                data_agendamento: new Date().toISOString(),
                status: 'Pendente'
              });
              
              clienteIndex++;
            }
          }
        }
      }
    };
    
    // Criar agendamentos para ambos vendedores
    criarAgendamentos(clientesVendedor1, 'Vendedor 1');
    criarAgendamentos(clientesVendedor2, 'Vendedor 2');
    
    // Salvar clientes no banco de dados
    clientes.forEach(cliente => {
      db.clientes[cliente.id_cliente] = cliente;
    });
    
    // Salvar agendamentos no banco de dados
    agendamentos.forEach(agendamento => {
      db.agendamentos[agendamento.id_agendamento] = agendamento;
    });
    
    // Registrar operação de sincronização
    db.sincronizacao.push({
      timestamp: new Date().toISOString(),
      dispositivo: 'servidor',
      operacao: 'importar',
      tabela: 'clientes_agendamentos',
      registros: clientes.length + agendamentos.length
    });
    
    // Salvar dados em arquivo
    salvarDados();
    
    log('info', 'Importação concluída', { clientes: clientes.length, agendamentos: agendamentos.length });
    
    res.json({ 
      success: true, 
      message: `${clientes.length} clientes importados e agendados com sucesso`,
      clientes: clientes.length,
      agendamentos: agendamentos.length
    });
  } catch (error) {
    log('error', 'Erro ao importar arquivo Excel:', error);
    res.status(500).json({ error: 'Erro ao importar arquivo Excel' });
  }
});

// Rota para exportar relatórios em Excel
app.get('/api/exportar/excel', async (req, res) => {
  try {
    // Obter dados do banco de dados
    const prospeccoes = db.prospeccoes;
    const clientes = db.clientes;
    
    log('info', 'Exportando relatório Excel');
    
    // Criar workbook Excel
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Sistema de Prospecção de Vendas';
    workbook.lastModifiedBy = 'Sistema de Prospecção de Vendas';
    workbook.created = new Date();
    workbook.modified = new Date();
    
    // Criar planilha de relatório
    const worksheet = workbook.addWorksheet('Relatório de Prospecções', {
      properties: { tabColor: { argb: '4F81BD' } }
    });
    
    // Definir colunas
    worksheet.columns = [
      { header: 'ID Cliente', key: 'id_cliente', width: 15 },
      { header: 'Nome', key: 'nome', width: 25 },
      { header: 'Empresa', key: 'empresa', width: 25 },
      { header: 'Telefone', key: 'telefone', width: 15 },
      { header: 'Email', key: 'email', width: 25 },
      { header: 'Vendedor', key: 'vendedor', width: 15 },
      { header: 'Status do Contato', key: 'statusContato', width: 20 },
      { header: 'Interesse', key: 'interesse', width: 15 },
      { header: 'Produtos de Interesse', key: 'produtosInteresse', width: 30 },
      { header: 'Fornecedor Atual', key: 'fornecedorAtual', width: 20 },
      { header: 'Condições Atuais', key: 'condicoesAtuais', width: 25 },
      { header: 'Probabilidade', key: 'probabilidade', width: 15 },
      { header: 'Valor Estimado', key: 'valorEstimado', width: 15 },
      { header: 'Próximos Passos', key: 'proximosPassos', width: 30 },
      { header: 'Observações', key: 'observacoes', width: 30 },
      { header: 'Data Salvamento', key: 'dataSalvamento', width: 20 }
    ];
    
    // Estilizar cabeçalho
    worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFF' } };
    worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4F81BD' } };
    worksheet.getRow(1).alignment = { vertical: 'middle', horizontal: 'center' };
    
    // Adicionar dados
    const dados = [];
    
    Object.values(prospeccoes).forEach(prospeccao => {
      const cliente = clientes[prospeccao.id_cliente] || {};
      
      dados.push({
        id_cliente: prospeccao.id_cliente,
        nome: cliente.nome || '',
        empresa: cliente.empresa || '',
        telefone: cliente.telefone || '',
        email: cliente.email || '',
        vendedor: prospeccao.vendedor || '',
        statusContato: prospeccao.statusContato || '',
        interesse: prospeccao.interesse || '',
        produtosInteresse: prospeccao.produtosInteresse || '',
        fornecedorAtual: prospeccao.fornecedorAtual || '',
        condicoesAtuais: prospeccao.condicoesAtuais || '',
        probabilidade: prospeccao.probabilidade || '',
        valorEstimado: prospeccao.valorEstimado || '',
        proximosPassos: prospeccao.proximosPassos || '',
        observacoes: prospeccao.observacoes || '',
        dataSalvamento: prospeccao.dataSalvamento || ''
      });
    });
    
    // Adicionar linhas
    worksheet.addRows(dados);
    
    // Aplicar estilos condicionais
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber > 1) {
        // Alternar cores de fundo para facilitar leitura
        const fill = rowNumber % 2 === 0 
          ? { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' } }
          : { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF' } };
        
        row.eachCell((cell) => {
          cell.fill = fill;
          cell.border = {
            top: { style: 'thin', color: { argb: 'D3D3D3' } },
            left: { style: 'thin', color: { argb: 'D3D3D3' } },
            bottom: { style: 'thin', color: { argb: 'D3D3D3' } },
            right: { style: 'thin', color: { argb: 'D3D3D3' } }
          };
          
          // Colorir células de status
          if (cell._column.key === 'statusContato') {
            const status = cell.value;
            if (status === 'Realizado') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C6EFCE' } }; // Verde claro
            } else if (status === 'Não Atendeu') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEB9C' } }; // Amarelo claro
            } else if (status === 'Número Inválido') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC7CE' } }; // Vermelho claro
            } else if (status === 'Reagendado') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'B4C6E7' } }; // Azul claro
            }
          }
          
          // Colorir células de probabilidade
          if (cell._column.key === 'probabilidade') {
            const probabilidade = cell.value;
            if (probabilidade === 'Alta') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C6EFCE' } }; // Verde claro
            } else if (probabilidade === 'Média') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEB9C' } }; // Amarelo claro
            } else if (probabilidade === 'Baixa') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC7CE' } }; // Vermelho claro
            }
          }
        });
      }
    });
    
    // Congelar cabeçalho
    worksheet.views = [
      { state: 'frozen', xSplit: 0, ySplit: 1, activeCell: 'A2' }
    ];
    
    // Configurar resposta
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=Relatorio_Prospeccoes.xlsx');
    
    // Enviar arquivo
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    log('error', 'Erro ao exportar relatório Excel:', error);
    res.status(500).json({ error: 'Erro ao exportar relatório Excel' });
  }
});

// Rota para sincronização
app.get('/api/sincronizacao', (req, res) => {
  const ultimaSincronizacao = req.query.timestamp || '0';
  
  // Filtrar prospecções atualizadas após a última sincronização
  const prospeccoesAtualizadas = {};
  Object.entries(db.prospeccoes).forEach(([id, prospeccao]) => {
    if (prospeccao.dataSalvamento && prospeccao.dataSalvamento > ultimaSincronizacao) {
      prospeccoesAtualizadas[id] = prospeccao;
    }
  });
  
  log('debug', 'Sincronização solicitada', { 
    ultimaSincronizacao, 
    atualizacoes: Object.keys(prospeccoesAtualizadas).length 
  });
  
  res.json({
    timestamp: new Date().toISOString(),
    prospeccoes: prospeccoesAtualizadas,
    total: Object.keys(prospeccoesAtualizadas).length
  });
});

// Rota para verificar saúde do sistema
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    memory: process.memoryUsage()
  });
});

// Servir o frontend para qualquer outra rota
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Iniciar o servidor
app.listen(config.server.port, config.server.host, () => {
  log('info', `Servidor rodando em http://${config.server.host}:${config.server.port}`);
  log('info', 'Sincronização em tempo real ativada');
});
