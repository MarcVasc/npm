// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBXH7JgXIWzi7DNwjN7LqUzZgOPjmyZj-8",
  authDomain: "prospeccao-vendas-sync.firebaseapp.com",
  projectId: "prospeccao-vendas-sync",
  storageBucket: "prospeccao-vendas-sync.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abc123def456ghi789jkl",
  databaseURL: "https://prospeccao-vendas-sync-default-rtdb.firebaseio.com"
};

module.exports = firebaseConfig;
