// Configuração para ambiente de produção
module.exports = {
  // Configurações do servidor
  server: {
    port: process.env.PORT || 3001,
    host: '0.0.0.0',
    // Em produção, usamos HTTPS se disponível
    useHttps: process.env.USE_HTTPS === 'true'
  },
  
  // Configurações de armazenamento
  storage: {
    // Diretório para armazenar dados
    dataDir: process.env.DATA_DIR || './data',
    // Intervalo de salvamento automático (em milissegundos)
    autoSaveInterval: parseInt(process.env.AUTO_SAVE_INTERVAL || '300000')
  },
  
  // Configurações de sincronização
  sync: {
    // Intervalo de sincronização (em milissegundos)
    interval: parseInt(process.env.SYNC_INTERVAL || '30000'),
    // Tempo limite para operações de sincronização (em milissegundos)
    timeout: parseInt(process.env.SYNC_TIMEOUT || '10000')
  },
  
  // Configurações de segurança
  security: {
    // Chave secreta para assinatura de cookies e tokens
    secretKey: process.env.SECRET_KEY || 'sistema-prospeccao-vendas-2025',
    // Tempo de expiração de sessão (em milissegundos)
    sessionExpiry: parseInt(process.env.SESSION_EXPIRY || '86400000')
  },
  
  // Configurações de log
  logging: {
    // Nível de log (debug, info, warn, error)
    level: process.env.LOG_LEVEL || 'info',
    // Arquivo de log
    file: process.env.LOG_FILE || './logs/app.log',
    // Rotação de logs
    maxSize: process.env.LOG_MAX_SIZE || '10m',
    maxFiles: parseInt(process.env.LOG_MAX_FILES || '7')
  }
};
