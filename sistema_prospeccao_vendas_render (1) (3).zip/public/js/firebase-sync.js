// Sistema de sincronização em tempo real usando Firebase
// Este arquivo implementa a sincronização entre diferentes dispositivos

// Classe para gerenciar a sincronização com Firebase
class FirebaseSync {
  constructor() {
    this.initialized = false;
    this.database = null;
    this.auth = null;
    this.currentUser = null;
    this.deviceId = this.generateDeviceId();
    this.lastSync = Date.now();
    this.syncActive = false;
    this.listeners = {};
    
    // Carregar scripts do Firebase
    this.loadFirebaseScripts()
      .then(() => this.initializeFirebase())
      .catch(error => {
        console.error('Erro ao carregar Firebase:', error);
        this.showErrorNotification('Erro de sincronização', 'Não foi possível carregar o Firebase. Tente recarregar a página.');
      });
  }
  
  // Gerar ID único para o dispositivo
  generateDeviceId() {
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
      deviceId = 'device_' + Math.random().toString(36).substring(2, 15);
      localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
  }
  
  // Carregar scripts do Firebase dinamicamente
  async loadFirebaseScripts() {
    return new Promise((resolve, reject) => {
      // Verificar se o Firebase já está carregado
      if (window.firebase) {
        console.log('Firebase já está carregado');
        resolve();
        return;
      }
      
      // Carregar Firebase App
      const scriptApp = document.createElement('script');
      scriptApp.src = 'https://www.gstatic.com/firebasejs/9.19.1/firebase-app-compat.js';
      scriptApp.onload = () => {
        console.log('Firebase App carregado');
        
        // Carregar Firebase Auth
        const scriptAuth = document.createElement('script');
        scriptAuth.src = 'https://www.gstatic.com/firebasejs/9.19.1/firebase-auth-compat.js';
        scriptAuth.onload = () => {
          console.log('Firebase Auth carregado');
          
          // Carregar Firebase Database
          const scriptDB = document.createElement('script');
          scriptDB.src = 'https://www.gstatic.com/firebasejs/9.19.1/firebase-database-compat.js';
          scriptDB.onload = () => {
            console.log('Firebase Database carregado');
            resolve();
          };
          scriptDB.onerror = reject;
          document.head.appendChild(scriptDB);
        };
        scriptAuth.onerror = reject;
        document.head.appendChild(scriptAuth);
      };
      scriptApp.onerror = reject;
      document.head.appendChild(scriptApp);
    });
  }
  
  // Inicializar Firebase
  initializeFirebase() {
    if (!window.firebase) {
      console.error('Firebase não está disponível');
      this.showErrorNotification('Erro de sincronização', 'Não foi possível inicializar o Firebase. Tente recarregar a página.');
      return;
    }
    
    try {
      // Configuração do Firebase
      const firebaseConfig = {
        apiKey: "AIzaSyBXH7JgXIWzi7DNwjN7LqUzZgOPjmyZj-8",
        authDomain: "prospeccao-vendas-sync.firebaseapp.com",
        projectId: "prospeccao-vendas-sync",
        storageBucket: "prospeccao-vendas-sync.appspot.com",
        messagingSenderId: "123456789012",
        appId: "1:123456789012:web:abc123def456ghi789jkl",
        databaseURL: "https://prospeccao-vendas-sync-default-rtdb.firebaseio.com"
      };
      
      // Inicializar Firebase
      firebase.initializeApp(firebaseConfig);
      
      // Obter referências
      this.database = firebase.database();
      this.auth = firebase.auth();
      
      // Autenticar anonimamente
      this.authenticateAnonymously();
      
      console.log('Firebase inicializado com sucesso');
      this.initialized = true;
    } catch (error) {
      console.error('Erro ao inicializar Firebase:', error);
      this.showErrorNotification('Erro de sincronização', 'Não foi possível inicializar o Firebase. Tente recarregar a página.');
    }
  }
  
  // Autenticar anonimamente
  authenticateAnonymously() {
    if (!this.auth) {
      console.error('Firebase Auth não está disponível');
      return;
    }
    
    this.auth.signInAnonymously()
      .then(result => {
        this.currentUser = result.user;
        console.log('Autenticado anonimamente com ID:', this.currentUser.uid);
        
        // Atualizar status para online
        this.updateOnlineStatus();
        
        // Iniciar sincronização
        this.startSync();
      })
      .catch(error => {
        console.error('Erro na autenticação anônima:', error);
        this.showErrorNotification('Erro de autenticação', 'Não foi possível autenticar com o servidor de sincronização.');
      });
  }
  
  // Atualizar status para online
  updateOnlineStatus() {
    const statusIndicator = document.getElementById('status-indicator');
    const statusText = document.getElementById('status-text');
    
    if (statusIndicator && statusText) {
      statusIndicator.className = 'status-indicator status-online';
      statusText.textContent = 'Online';
    }
    
    this.showNotification('Sistema sincronizado', 'Você está conectado ao sistema de sincronização em tempo real', 'success');
  }
  
  // Iniciar sincronização
  startSync() {
    if (!this.initialized || !this.currentUser) {
      console.error('Firebase não está inicializado ou usuário não autenticado');
      return;
    }
    
    console.log('Iniciando sincronização com Firebase');
    this.syncActive = true;
    
    // Configurar listeners para mudanças
    this.setupChangeListeners();
    
    // Verificar dados existentes
    this.checkExistingData();
  }
  
  // Configurar listeners para mudanças
  setupChangeListeners() {
    if (!this.database) {
      console.error('Firebase Database não está disponível');
      return;
    }
    
    console.log('Configurando listeners para mudanças no Firebase');
    
    // Listener para prospecções
    const prospeccoesRef = this.database.ref('prospeccoes');
    
    // Quando uma prospecção é atualizada
    prospeccoesRef.on('child_changed', snapshot => {
      const updatedProspection = snapshot.val();
      const id = snapshot.key;
      
      console.log('Prospecção atualizada no Firebase:', id, updatedProspection);
      
      // Verificar se não foi este dispositivo que fez a atualização
      if (updatedProspection.dispositivo !== this.deviceId) {
        // Atualizar dados locais
        this.updateLocalData(id, updatedProspection);
        
        // Mostrar notificação
        this.showNotification(
          'Dados atualizados', 
          `Cliente ${updatedProspection.nome || id} foi atualizado por ${updatedProspection.vendedor || 'outro usuário'}`, 
          'info'
        );
        
        // Atualizar UI
        this.updateUI();
      }
    });
    
    // Quando uma nova prospecção é adicionada
    prospeccoesRef.on('child_added', snapshot => {
      const newProspection = snapshot.val();
      const id = snapshot.key;
      
      // Verificar se não foi este dispositivo que adicionou
      if (newProspection.dispositivo !== this.deviceId) {
        console.log('Nova prospecção adicionada no Firebase:', id, newProspection);
        
        // Atualizar dados locais
        this.updateLocalData(id, newProspection);
        
        // Mostrar notificação
        this.showNotification(
          'Nova prospecção', 
          `Cliente ${newProspection.nome || id} foi adicionado por ${newProspection.vendedor || 'outro usuário'}`, 
          'info'
        );
        
        // Atualizar UI
        this.updateUI();
      }
    });
    
    // Listener para sincronização
    const sincronizacaoRef = this.database.ref('sincronizacao');
    sincronizacaoRef.limitToLast(1).on('child_added', snapshot => {
      const syncEvent = snapshot.val();
      
      // Verificar se não foi este dispositivo que gerou o evento
      if (syncEvent.dispositivo !== this.deviceId) {
        console.log('Evento de sincronização detectado:', syncEvent);
        
        // Atualizar UI se necessário
        if (syncEvent.operacao === 'importar') {
          this.showNotification(
            'Dados importados', 
            'Novos dados foram importados para o sistema. Atualizando...', 
            'info'
          );
          
          // Recarregar dados
          this.reloadData();
        }
      }
    });
  }
  
  // Verificar dados existentes
  checkExistingData() {
    if (!this.database) {
      console.error('Firebase Database não está disponível');
      return;
    }
    
    console.log('Verificando dados existentes no Firebase');
    
    // Verificar se há clientes
    this.database.ref('clientes').once('value')
      .then(snapshot => {
        const clientes = snapshot.val();
        if (!clientes) {
          console.log('Nenhum cliente encontrado no Firebase');
          
          // Verificar se há arquivo de importação
          this.checkImportFile();
        } else {
          console.log(`${Object.keys(clientes).length} clientes encontrados no Firebase`);
          
          // Carregar dados
          this.loadData();
        }
      })
      .catch(error => {
        console.error('Erro ao verificar clientes:', error);
      });
  }
  
  // Verificar se há arquivo de importação
  checkImportFile() {
    // Esta função seria chamada se não houver clientes no Firebase
    // Poderia mostrar um modal para importar arquivo Excel
    console.log('Verificando arquivo de importação');
    
    // Mostrar botão de importação se estiver na página principal
    if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
      const importButton = document.getElementById('import-button');
      if (importButton) {
        importButton.style.display = 'block';
      }
    }
  }
  
  // Carregar dados
  loadData() {
    if (!this.database) {
      console.error('Firebase Database não está disponível');
      return;
    }
    
    console.log('Carregando dados do Firebase');
    
    // Carregar clientes
    this.database.ref('clientes').once('value')
      .then(snapshot => {
        const clientes = snapshot.val() || {};
        console.log(`${Object.keys(clientes).length} clientes carregados`);
        
        // Armazenar clientes em variável global
        window.clientes = clientes;
        
        // Carregar agendamentos
        return this.database.ref('agendamentos').once('value');
      })
      .then(snapshot => {
        const agendamentos = snapshot.val() || {};
        console.log(`${Object.keys(agendamentos).length} agendamentos carregados`);
        
        // Armazenar agendamentos em variável global
        window.agendamentos = agendamentos;
        
        // Carregar prospecções
        return this.database.ref('prospeccoes').once('value');
      })
      .then(snapshot => {
        const prospeccoes = snapshot.val() || {};
        console.log(`${Object.keys(prospeccoes).length} prospecções carregadas`);
        
        // Armazenar prospecções em variável global
        window.prospeccoes = prospeccoes;
        
        // Atualizar UI
        this.updateUI();
      })
      .catch(error => {
        console.error('Erro ao carregar dados:', error);
        this.showErrorNotification('Erro ao carregar dados', 'Não foi possível carregar os dados do servidor.');
      });
  }
  
  // Recarregar dados
  reloadData() {
    console.log('Recarregando dados do Firebase');
    this.loadData();
  }
  
  // Atualizar dados locais
  updateLocalData(id, data) {
    console.log('Atualizando dados locais:', id, data);
    
    // Atualizar prospecções
    if (window.prospeccoes) {
      window.prospeccoes[id] = data;
    }
  }
  
  // Atualizar UI
  updateUI() {
    console.log('Atualizando interface do usuário');
    
    // Se estiver na página de agenda
    if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
      // Atualizar lista de clientes
      if (typeof window.carregarClientes === 'function') {
        window.carregarClientes();
      }
      
      // Atualizar formulário se estiver visualizando um cliente
      const clienteIdAtual = document.getElementById('cliente-id')?.value;
      if (clienteIdAtual && typeof window.carregarDadosCliente === 'function') {
        window.carregarDadosCliente(clienteIdAtual);
      }
    }
    
    // Se estiver na página de relatórios
    if (window.location.pathname.includes('relatorios.html')) {
      // Atualizar relatórios
      if (typeof window.carregarDadosRelatorios === 'function') {
        window.carregarDadosRelatorios();
      }
    }
  }
  
  // Salvar prospecção
  saveProspection(data) {
    if (!this.initialized || !this.database || !this.syncActive) {
      console.error('Firebase não está inicializado ou sincronização não está ativa');
      return Promise.reject(new Error('Firebase não está inicializado'));
    }
    
    console.log('Salvando prospecção:', data);
    
    // Adicionar informações do dispositivo
    data.dispositivo = this.deviceId;
    data.data_salvamento = new Date().toISOString();
    
    // Enviar para o servidor
    return fetch('/api/prospeccoes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prospeccao: data,
        dispositivo: this.deviceId
      })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Erro ao salvar prospecção');
      }
      return response.json();
    })
    .then(result => {
      console.log('Prospecção salva com sucesso:', result);
      
      // Atualizar dados locais
      this.updateLocalData(data.id_cliente, data);
      
      // Mostrar notificação
      this.showNotification('Dados salvos', 'Os dados foram salvos e sincronizados com sucesso', 'success');
      
      return result;
    })
    .catch(error => {
      console.error('Erro ao salvar prospecção:', error);
      this.showErrorNotification('Erro ao salvar', 'Não foi possível salvar os dados no servidor.');
      
      // Tentar salvar diretamente no Firebase como fallback
      return this.saveProspectionDirectly(data);
    });
  }
  
  // Salvar prospecção diretamente no Firebase (fallback)
  saveProspectionDirectly(data) {
    if (!this.database) {
      return Promise.reject(new Error('Firebase Database não está disponível'));
    }
    
    console.log('Tentando salvar prospecção diretamente no Firebase:', data);
    
    return this.database.ref(`prospeccoes/${data.id_cliente}`).set(data)
      .then(() => {
        console.log('Prospecção salva diretamente no Firebase com sucesso');
        
        // Registrar operação de sincronização
        return this.database.ref('sincronizacao').push({
          timestamp: data.data_salvamento,
          dispositivo: this.deviceId,
          operacao: 'salvar',
          tabela: 'prospeccoes',
          registro_id: data.id_cliente
        });
      })
      .then(() => {
        // Mostrar notificação
        this.showNotification('Dados salvos', 'Os dados foram salvos diretamente no Firebase', 'success');
        
        return { success: true, message: 'Dados salvos diretamente no Firebase' };
      })
      .catch(error => {
        console.error('Erro ao salvar diretamente no Firebase:', error);
        this.showErrorNotification('Erro ao salvar', 'Não foi possível salvar os dados nem mesmo diretamente no Firebase.');
        
        return Promise.reject(error);
      });
  }
  
  // Importar arquivo Excel
  importExcelFile(file) {
    if (!file) {
      this.showErrorNotification('Erro de importação', 'Nenhum arquivo selecionado');
      return Promise.reject(new Error('Nenhum arquivo selecionado'));
    }
    
    console.log('Importando arquivo Excel:', file.name);
    
    const formData = new FormData();
    formData.append('arquivo', file);
    
    return fetch('/api/importar/excel', {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Erro ao importar arquivo');
      }
      return response.json();
    })
    .then(result => {
      console.log('Arquivo importado com sucesso:', result);
      
      // Mostrar notificação
      this.showNotification(
        'Importação concluída', 
        `${result.clientes} clientes importados e agendados com sucesso`, 
        'success'
      );
      
      // Recarregar dados
      this.reloadData();
      
      return result;
    })
    .catch(error => {
      console.error('Erro ao importar arquivo:', error);
      this.showErrorNotification('Erro de importação', 'Não foi possível importar o arquivo Excel.');
      
      return Promise.reject(error);
    });
  }
  
  // Exportar relatório Excel
  exportExcelReport() {
    console.log('Exportando relatório Excel');
    
    // Redirecionar para a URL de exportação
    window.location.href = '/api/exportar/excel';
  }
  
  // Mostrar notificação
  showNotification(title, message, type = 'info') {
    console.log(`Notificação (${type}):`, title, message);
    
    // Verificar se a função global está disponível
    if (typeof window.showNotification === 'function') {
      window.showNotification(title, message, type);
    } else {
      // Implementação local
      this.showLocalNotification(title, message, type);
    }
  }
  
  // Mostrar notificação de erro
  showErrorNotification(title, message) {
    this.showNotification(title, message, 'danger');
  }
  
  // Implementação local de mostrar notificação
  showLocalNotification(title, message, type = 'info') {
    // Verificar se o container de notificações existe
    let notificationArea = document.getElementById('notification-area');
    
    // Se não existir, criar
    if (!notificationArea) {
      notificationArea = document.createElement('div');
      notificationArea.id = 'notification-area';
      notificationArea.style.position = 'fixed';
      notificationArea.style.top = '70px';
      notificationArea.style.right = '20px';
      notificationArea.style.width = '300px';
      notificationArea.style.zIndex = '1050';
      document.body.appendChild(notificationArea);
    }
    
    // Criar elemento de notificação
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.role = 'alert';
    
    // Adicionar conteúdo
    notification.innerHTML = `
      <strong>${title}</strong>
      <p>${message}</p>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Adicionar ao container
    notificationArea.appendChild(notification);
    
    // Auto-fechar após 5 segundos
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, 5000);
  }
}

// Inicializar sincronização
const firebaseSync = new FirebaseSync();

// Exportar para uso global
window.firebaseSync = firebaseSync;

// Sobrescrever função de salvamento para incluir sincronização
window.salvarDadosProspeccao = function(dados) {
  console.log('Salvando dados de prospecção com sincronização:', dados);
  
  if (window.firebaseSync) {
    return window.firebaseSync.saveProspection(dados);
  } else {
    console.error('Sistema de sincronização não está disponível');
    return Promise.reject(new Error('Sistema de sincronização não está disponível'));
  }
};

// Função para importar arquivo Excel
window.importarArquivoExcel = function(file) {
  if (window.firebaseSync) {
    return window.firebaseSync.importExcelFile(file);
  } else {
    console.error('Sistema de sincronização não está disponível');
    return Promise.reject(new Error('Sistema de sincronização não está disponível'));
  }
};

// Função para exportar relatório Excel
window.exportarRelatorioExcel = function() {
  if (window.firebaseSync) {
    return window.firebaseSync.exportExcelReport();
  } else {
    console.error('Sistema de sincronização não está disponível');
    alert('Sistema de sincronização não está disponível. Não é possível exportar o relatório.');
  }
};
