// Sistema de sincronização simplificado
// Este arquivo implementa a sincronização entre diferentes dispositivos sem depender de serviços externos

// Classe para gerenciar a sincronização
class SincronizacaoSimples {
  constructor() {
    this.initialized = false;
    this.deviceId = this.generateDeviceId();
    this.lastSync = Date.now();
    this.syncActive = false;
    this.syncInterval = null;
    this.statusIndicator = document.getElementById('status-indicator');
    this.statusText = document.getElementById('status-text');
    
    // Inicializar
    this.initialize();
  }
  
  // Gerar ID único para o dispositivo
  generateDeviceId() {
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
      deviceId = 'device_' + Math.random().toString(36).substring(2, 15);
      localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
  }
  
  // Inicializar sincronização
  initialize() {
    console.log('Inicializando sistema de sincronização simplificado');
    
    // Verificar status do servidor
    this.checkServerStatus()
      .then(online => {
        if (online) {
          this.updateOnlineStatus();
          this.startSync();
        } else {
          this.updateOfflineStatus();
        }
      })
      .catch(error => {
        console.error('Erro ao verificar status do servidor:', error);
        this.updateOfflineStatus();
      });
  }
  
  // Verificar status do servidor
  async checkServerStatus() {
    try {
      const response = await fetch('/api/status');
      if (!response.ok) {
        throw new Error('Servidor não está respondendo corretamente');
      }
      const data = await response.json();
      return data.status === 'online';
    } catch (error) {
      console.error('Erro ao verificar status do servidor:', error);
      return false;
    }
  }
  
  // Atualizar status para online
  updateOnlineStatus() {
    console.log('Sistema online');
    
    if (this.statusIndicator && this.statusText) {
      this.statusIndicator.className = 'status-indicator status-online';
      this.statusText.textContent = 'Online';
    }
    
    this.showNotification('Sistema sincronizado', 'Você está conectado ao sistema de sincronização', 'success');
    this.initialized = true;
  }
  
  // Atualizar status para offline
  updateOfflineStatus() {
    console.log('Sistema offline');
    
    if (this.statusIndicator && this.statusText) {
      this.statusIndicator.className = 'status-indicator status-offline';
      this.statusText.textContent = 'Offline';
    }
    
    this.showNotification('Sistema offline', 'Você está trabalhando no modo offline. As alterações serão sincronizadas quando a conexão for restabelecida.', 'warning');
  }
  
  // Iniciar sincronização
  startSync() {
    console.log('Iniciando sincronização');
    this.syncActive = true;
    
    // Carregar dados iniciais
    this.loadInitialData();
    
    // Configurar sincronização periódica
    this.syncInterval = setInterval(() => {
      this.syncData();
    }, 30000); // Sincronizar a cada 30 segundos
  }
  
  // Parar sincronização
  stopSync() {
    console.log('Parando sincronização');
    this.syncActive = false;
    
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }
  
  // Carregar dados iniciais
  async loadInitialData() {
    console.log('Carregando dados iniciais');
    
    try {
      // Carregar clientes
      const clientesResponse = await fetch('/api/clientes');
      if (clientesResponse.ok) {
        const clientes = await clientesResponse.json();
        window.clientes = clientes;
        console.log(`${Object.keys(clientes).length} clientes carregados`);
      }
      
      // Carregar agendamentos
      const agendamentosResponse = await fetch('/api/agendamentos');
      if (agendamentosResponse.ok) {
        const agendamentos = await agendamentosResponse.json();
        window.agendamentos = agendamentos;
        console.log(`${Object.keys(agendamentos).length} agendamentos carregados`);
      }
      
      // Carregar prospecções
      const prospeccoesResponse = await fetch('/api/prospeccoes');
      if (prospeccoesResponse.ok) {
        const prospeccoes = await prospeccoesResponse.json();
        window.prospeccoes = prospeccoes;
        console.log(`${Object.keys(prospeccoes).length} prospecções carregadas`);
      }
      
      // Atualizar UI
      this.updateUI();
    } catch (error) {
      console.error('Erro ao carregar dados iniciais:', error);
      this.showErrorNotification('Erro ao carregar dados', 'Não foi possível carregar os dados do servidor. Verifique sua conexão.');
    }
  }
  
  // Sincronizar dados
  async syncData() {
    if (!this.syncActive) return;
    
    console.log('Sincronizando dados');
    
    try {
      // Verificar se há atualizações desde a última sincronização
      const response = await fetch(`/api/sincronizacao?timestamp=${this.lastSync}`);
      if (!response.ok) {
        throw new Error('Erro ao sincronizar dados');
      }
      
      const data = await response.json();
      this.lastSync = data.timestamp;
      
      // Verificar se há prospecções atualizadas
      if (data.total > 0) {
        console.log(`${data.total} prospecções atualizadas`);
        
        // Atualizar dados locais
        Object.entries(data.prospeccoes).forEach(([id, prospeccao]) => {
          // Verificar se não foi este dispositivo que fez a atualização
          if (prospeccao.dispositivo !== this.deviceId) {
            console.log(`Atualizando prospecção ${id} de outro dispositivo`);
            
            // Atualizar dados locais
            window.prospeccoes[id] = prospeccao;
            
            // Mostrar notificação
            this.showNotification(
              'Dados atualizados', 
              `Cliente ${prospeccao.nome || id} foi atualizado por ${prospeccao.vendedor || 'outro usuário'}`, 
              'info'
            );
          }
        });
        
        // Atualizar UI
        this.updateUI();
      }
    } catch (error) {
      console.error('Erro ao sincronizar dados:', error);
      
      // Verificar se o servidor está online
      this.checkServerStatus()
        .then(online => {
          if (!online) {
            this.updateOfflineStatus();
            this.stopSync();
          }
        });
    }
  }
  
  // Atualizar UI
  updateUI() {
    console.log('Atualizando interface do usuário');
    
    // Se estiver na página de agenda
    if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
      // Atualizar lista de clientes
      if (typeof window.carregarClientes === 'function') {
        window.carregarClientes();
      }
      
      // Atualizar formulário se estiver visualizando um cliente
      const clienteIdAtual = document.getElementById('cliente-id')?.value;
      if (clienteIdAtual && typeof window.carregarDadosCliente === 'function') {
        window.carregarDadosCliente(clienteIdAtual);
      }
    }
    
    // Se estiver na página de relatórios
    if (window.location.pathname.includes('relatorios.html')) {
      // Atualizar relatórios
      if (typeof window.carregarDadosRelatorios === 'function') {
        window.carregarDadosRelatorios();
      }
    }
  }
  
  // Salvar prospecção
  async saveProspection(data) {
    console.log('Salvando prospecção:', data);
    
    // Adicionar informações do dispositivo
    data.dispositivo = this.deviceId;
    data.dataSalvamento = new Date().toISOString();
    
    try {
      // Enviar para o servidor
      const response = await fetch('/api/prospeccoes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prospeccao: data,
          dispositivo: this.deviceId
        })
      });
      
      if (!response.ok) {
        throw new Error('Erro ao salvar prospecção');
      }
      
      const result = await response.json();
      console.log('Prospecção salva com sucesso:', result);
      
      // Atualizar dados locais
      window.prospeccoes[data.id_cliente] = data;
      
      // Mostrar notificação
      this.showNotification('Dados salvos', 'Os dados foram salvos e sincronizados com sucesso', 'success');
      
      // Atualizar UI
      this.updateUI();
      
      return result;
    } catch (error) {
      console.error('Erro ao salvar prospecção:', error);
      
      // Verificar se o servidor está online
      const online = await this.checkServerStatus();
      
      if (!online) {
        this.updateOfflineStatus();
        
        // Salvar localmente para sincronização posterior
        this.saveLocalProspection(data);
        
        // Mostrar notificação
        this.showNotification('Dados salvos localmente', 'Os dados foram salvos localmente e serão sincronizados quando a conexão for restabelecida', 'warning');
        
        return { success: true, message: 'Dados salvos localmente', offline: true };
      } else {
        this.showErrorNotification('Erro ao salvar', 'Não foi possível salvar os dados no servidor.');
        return Promise.reject(error);
      }
    }
  }
  
  // Salvar prospecção localmente
  saveLocalProspection(data) {
    console.log('Salvando prospecção localmente:', data);
    
    // Obter prospecções pendentes
    let pendingProspections = JSON.parse(localStorage.getItem('pendingProspections') || '[]');
    
    // Adicionar nova prospecção
    pendingProspections.push(data);
    
    // Salvar no localStorage
    localStorage.setItem('pendingProspections', JSON.stringify(pendingProspections));
    
    // Atualizar dados locais
    window.prospeccoes[data.id_cliente] = data;
    
    // Atualizar UI
    this.updateUI();
  }
  
  // Sincronizar prospecções pendentes
  async syncPendingProspections() {
    console.log('Sincronizando prospecções pendentes');
    
    // Verificar se há prospecções pendentes
    const pendingProspections = JSON.parse(localStorage.getItem('pendingProspections') || '[]');
    
    if (pendingProspections.length === 0) {
      console.log('Nenhuma prospecção pendente para sincronizar');
      return;
    }
    
    console.log(`${pendingProspections.length} prospecções pendentes para sincronizar`);
    
    // Verificar se o servidor está online
    const online = await this.checkServerStatus();
    
    if (!online) {
      console.log('Servidor offline, não é possível sincronizar prospecções pendentes');
      return;
    }
    
    // Sincronizar cada prospecção
    const successfulSync = [];
    
    for (const prospeccao of pendingProspections) {
      try {
        const response = await fetch('/api/prospeccoes', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            prospeccao: prospeccao,
            dispositivo: this.deviceId
          })
        });
        
        if (response.ok) {
          successfulSync.push(prospeccao.id_cliente);
        }
      } catch (error) {
        console.error(`Erro ao sincronizar prospecção ${prospeccao.id_cliente}:`, error);
      }
    }
    
    // Remover prospecções sincronizadas com sucesso
    if (successfulSync.length > 0) {
      const remainingProspections = pendingProspections.filter(p => !successfulSync.includes(p.id_cliente));
      localStorage.setItem('pendingProspections', JSON.stringify(remainingProspections));
      
      console.log(`${successfulSync.length} prospecções sincronizadas com sucesso`);
      
      // Mostrar notificação
      this.showNotification(
        'Sincronização concluída', 
        `${successfulSync.length} prospecções foram sincronizadas com sucesso`, 
        'success'
      );
    }
  }
  
  // Importar arquivo Excel
  async importExcelFile(file) {
    if (!file) {
      this.showErrorNotification('Erro de importação', 'Nenhum arquivo selecionado');
      return Promise.reject(new Error('Nenhum arquivo selecionado'));
    }
    
    console.log('Importando arquivo Excel:', file.name);
    
    const formData = new FormData();
    formData.append('arquivo', file);
    
    try {
      const response = await fetch('/api/importar/excel', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        throw new Error('Erro ao importar arquivo');
      }
      
      const result = await response.json();
      console.log('Arquivo importado com sucesso:', result);
      
      // Mostrar notificação
      this.showNotification(
        'Importação concluída', 
        `${result.clientes} clientes importados e agendados com sucesso`, 
        'success'
      );
      
      // Recarregar dados
      this.loadInitialData();
      
      return result;
    } catch (error) {
      console.error('Erro ao importar arquivo:', error);
      this.showErrorNotification('Erro de importação', 'Não foi possível importar o arquivo Excel.');
      
      return Promise.reject(error);
    }
  }
  
  // Exportar relatório Excel
  exportExcelReport() {
    console.log('Exportando relatório Excel');
    
    // Redirecionar para a URL de exportação
    window.location.href = '/api/exportar/excel';
  }
  
  // Mostrar notificação
  showNotification(title, message, type = 'info') {
    console.log(`Notificação (${type}):`, title, message);
    
    // Verificar se a função global está disponível
    if (typeof window.showNotification === 'function') {
      window.showNotification(title, message, type);
    } else {
      // Implementação local
      this.showLocalNotification(title, message, type);
    }
  }
  
  // Mostrar notificação de erro
  showErrorNotification(title, message) {
    this.showNotification(title, message, 'danger');
  }
  
  // Implementação local de mostrar notificação
  showLocalNotification(title, message, type = 'info') {
    // Verificar se o container de notificações existe
    let notificationArea = document.getElementById('notification-area');
    
    // Se não existir, criar
    if (!notificationArea) {
      notificationArea = document.createElement('div');
      notificationArea.id = 'notification-area';
      notificationArea.style.position = 'fixed';
      notificationArea.style.top = '70px';
      notificationArea.style.right = '20px';
      notificationArea.style.width = '300px';
      notificationArea.style.zIndex = '1050';
      document.body.appendChild(notificationArea);
    }
    
    // Criar elemento de notificação
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.role = 'alert';
    
    // Adicionar conteúdo
    notification.innerHTML = `
      <strong>${title}</strong>
      <p>${message}</p>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Adicionar ao container
    notificationArea.appendChild(notification);
    
    // Auto-fechar após 5 segundos
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, 5000);
  }
}

// Inicializar sincronização
const sincronizacaoSimples = new SincronizacaoSimples();

// Exportar para uso global
window.sincronizacaoSimples = sincronizacaoSimples;

// Sobrescrever função de salvamento para incluir sincronização
window.salvarDadosProspeccao = function(dados) {
  console.log('Salvando dados de prospecção com sincronização:', dados);
  
  if (window.sincronizacaoSimples) {
    return window.sincronizacaoSimples.saveProspection(dados);
  } else {
    console.error('Sistema de sincronização não está disponível');
    return Promise.reject(new Error('Sistema de sincronização não está disponível'));
  }
};

// Função para importar arquivo Excel
window.importarArquivoExcel = function(file) {
  if (window.sincronizacaoSimples) {
    return window.sincronizacaoSimples.importExcelFile(file);
  } else {
    console.error('Sistema de sincronização não está disponível');
    return Promise.reject(new Error('Sistema de sincronização não está disponível'));
  }
};

// Função para exportar relatório Excel
window.exportarRelatorioExcel = function() {
  if (window.sincronizacaoSimples) {
    return window.sincronizacaoSimples.exportExcelReport();
  } else {
    console.error('Sistema de sincronização não está disponível');
    alert('Sistema de sincronização não está disponível. Não é possível exportar o relatório.');
  }
};
