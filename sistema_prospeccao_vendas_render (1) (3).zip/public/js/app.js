// Aplicação principal para o Sistema de Prospecção de Vendas
// Este arquivo gerencia a interface do usuário e a interação com o sistema de sincronização

// Variáveis globais
let vendedorAtual = 'Vendedor 1';
let diaSemanaAtual = 'segunda';
let periodoAtual = 'manha';
let clienteAtual = null;

// Clientes, agendamentos e prospecções
window.clientes = {};
window.agendamentos = {};
window.prospeccoes = {};

// Função para inicializar a aplicação
function inicializarApp() {
    console.log('Inicializando aplicação...');
    
    // Configurar eventos de botões
    configurarEventosBotoes();
    
    // Configurar evento de importação
    configurarEventoImportacao();
    
    // Carregar dados iniciais
    setTimeout(() => {
        if (window.firebaseSync) {
            console.log('Firebase Sync disponível, carregando dados...');
        } else {
            console.warn('Firebase Sync não disponível, usando dados locais...');
            // Mostrar botão de importação
            document.getElementById('import-button').style.display = 'block';
        }
    }, 1000);
}

// Configurar eventos de botões
function configurarEventosBotoes() {
    // Botões de vendedor
    document.getElementById('btn-vendedor1').addEventListener('click', () => {
        alterarVendedor('Vendedor 1');
    });
    
    document.getElementById('btn-vendedor2').addEventListener('click', () => {
        alterarVendedor('Vendedor 2');
    });
    
    // Botões de dia da semana
    document.getElementById('btn-segunda').addEventListener('click', () => {
        alterarDiaSemana('segunda');
    });
    
    document.getElementById('btn-terca').addEventListener('click', () => {
        alterarDiaSemana('terca');
    });
    
    document.getElementById('btn-quarta').addEventListener('click', () => {
        alterarDiaSemana('quarta');
    });
    
    document.getElementById('btn-quinta').addEventListener('click', () => {
        alterarDiaSemana('quinta');
    });
    
    document.getElementById('btn-sexta').addEventListener('click', () => {
        alterarDiaSemana('sexta');
    });
    
    // Botão de salvar
    document.getElementById('btn-salvar').addEventListener('click', () => {
        salvarDadosFormulario();
    });
}

// Configurar evento de importação
function configurarEventoImportacao() {
    const btnImportExcel = document.getElementById('btn-import-excel');
    if (btnImportExcel) {
        btnImportExcel.addEventListener('click', () => {
            const fileInput = document.getElementById('excel-file');
            if (fileInput && fileInput.files.length > 0) {
                const file = fileInput.files[0];
                importarArquivoExcel(file);
            } else {
                showNotification('Erro', 'Selecione um arquivo Excel para importar', 'danger');
            }
        });
    }
}

// Alterar vendedor
function alterarVendedor(vendedor) {
    console.log('Alterando vendedor para:', vendedor);
    
    // Atualizar variável global
    vendedorAtual = vendedor;
    
    // Atualizar UI
    document.getElementById('btn-vendedor1').classList.remove('active');
    document.getElementById('btn-vendedor2').classList.remove('active');
    
    if (vendedor === 'Vendedor 1') {
        document.getElementById('btn-vendedor1').classList.add('active');
    } else {
        document.getElementById('btn-vendedor2').classList.add('active');
    }
    
    // Carregar clientes do vendedor
    carregarClientes();
}

// Alterar dia da semana
function alterarDiaSemana(diaSemana) {
    console.log('Alterando dia da semana para:', diaSemana);
    
    // Atualizar variável global
    diaSemanaAtual = diaSemana;
    
    // Atualizar UI
    document.getElementById('btn-segunda').classList.remove('active');
    document.getElementById('btn-terca').classList.remove('active');
    document.getElementById('btn-quarta').classList.remove('active');
    document.getElementById('btn-quinta').classList.remove('active');
    document.getElementById('btn-sexta').classList.remove('active');
    
    document.getElementById(`btn-${diaSemana}`).classList.add('active');
    
    // Carregar clientes do dia
    carregarClientes();
}

// Carregar clientes
function carregarClientes() {
    console.log('Carregando clientes para:', vendedorAtual, diaSemanaAtual);
    
    const clientesContainer = document.getElementById('clientes-container');
    
    // Mostrar loading
    clientesContainer.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Carregando clientes...</span>
            </div>
            <p class="mt-3">Carregando clientes...</p>
        </div>
    `;
    
    // Verificar se temos agendamentos
    if (!window.agendamentos || Object.keys(window.agendamentos).length === 0) {
        // Tentar carregar do servidor
        fetch('/api/agendamentos')
            .then(response => response.json())
            .then(data => {
                window.agendamentos = data;
                renderizarClientes();
            })
            .catch(error => {
                console.error('Erro ao carregar agendamentos:', error);
                clientesContainer.innerHTML = `
                    <div class="alert alert-danger m-3">
                        <h5>Erro ao carregar clientes</h5>
                        <p>Não foi possível carregar os agendamentos. Tente novamente mais tarde.</p>
                    </div>
                `;
            });
    } else {
        renderizarClientes();
    }
}

// Renderizar clientes
function renderizarClientes() {
    const clientesContainer = document.getElementById('clientes-container');
    
    // Filtrar agendamentos pelo vendedor e dia da semana
    const agendamentosFiltrados = Object.values(window.agendamentos).filter(agendamento => {
        return agendamento.vendedor === vendedorAtual && agendamento.dia_semana === diaSemanaAtual;
    });
    
    // Ordenar por período (manhã/tarde) e ordem
    agendamentosFiltrados.sort((a, b) => {
        if (a.periodo === b.periodo) {
            return a.ordem - b.ordem;
        }
        return a.periodo === 'manha' ? -1 : 1;
    });
    
    // Verificar se há agendamentos
    if (agendamentosFiltrados.length === 0) {
        clientesContainer.innerHTML = `
            <div class="alert alert-info m-3">
                <h5>Nenhum cliente agendado</h5>
                <p>Não há clientes agendados para ${vendedorAtual} na ${diaSemanaAtual}.</p>
            </div>
        `;
        return;
    }
    
    // Criar HTML para os clientes
    let htmlManha = '<h6 class="mt-2 mb-2 ps-2">Período: Manhã</h6>';
    let htmlTarde = '<h6 class="mt-3 mb-2 ps-2">Período: Tarde</h6>';
    
    // Verificar se temos clientes
    if (!window.clientes || Object.keys(window.clientes).length === 0) {
        // Tentar carregar do servidor
        fetch('/api/clientes')
            .then(response => response.json())
            .then(data => {
                window.clientes = data;
                continuarRenderizacao();
            })
            .catch(error => {
                console.error('Erro ao carregar clientes:', error);
                clientesContainer.innerHTML = `
                    <div class="alert alert-danger m-3">
                        <h5>Erro ao carregar clientes</h5>
                        <p>Não foi possível carregar os dados dos clientes. Tente novamente mais tarde.</p>
                    </div>
                `;
            });
    } else {
        continuarRenderizacao();
    }
    
    // Continuar renderização após carregar clientes
    function continuarRenderizacao() {
        // Verificar se temos prospecções
        if (!window.prospeccoes || Object.keys(window.prospeccoes).length === 0) {
            // Tentar carregar do servidor
            fetch('/api/prospeccoes')
                .then(response => response.json())
                .then(data => {
                    window.prospeccoes = data;
                    finalizarRenderizacao();
                })
                .catch(error => {
                    console.error('Erro ao carregar prospecções:', error);
                    // Continuar mesmo sem prospecções
                    finalizarRenderizacao();
                });
        } else {
            finalizarRenderizacao();
        }
    }
    
    // Finalizar renderização após carregar todos os dados
    function finalizarRenderizacao() {
        // Criar lista de clientes para cada período
        let clientesManha = [];
        let clientesTarde = [];
        
        agendamentosFiltrados.forEach(agendamento => {
            const cliente = window.clientes[agendamento.id_cliente];
            if (!cliente) return;
            
            // Verificar se há prospecção para este cliente
            const prospeccao = window.prospeccoes[agendamento.id_cliente];
            
            // Determinar classe CSS baseada no status da prospecção
            let classeStatus = '';
            if (prospeccao && prospeccao.statusContato) {
                switch (prospeccao.statusContato) {
                    case 'Realizado':
                        classeStatus = 'cliente-realizado';
                        break;
                    case 'Não Atendeu':
                        classeStatus = 'cliente-nao-atendeu';
                        break;
                    case 'Número Inválido':
                        classeStatus = 'cliente-invalido';
                        break;
                    case 'Reagendado':
                        classeStatus = 'cliente-reagendado';
                        break;
                }
            }
            
            // Criar item de cliente
            const itemCliente = `
                <a href="#" class="list-group-item list-group-item-action ${classeStatus}" 
                   data-id="${agendamento.id_cliente}" onclick="carregarDadosCliente('${agendamento.id_cliente}')">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">${cliente.nome || 'Cliente sem nome'}</h6>
                        <small>${agendamento.ordem}</small>
                    </div>
                    <p class="mb-1">${cliente.empresa || 'Empresa não informada'}</p>
                    <small>${cliente.telefone || 'Telefone não informado'}</small>
                </a>
            `;
            
            // Adicionar ao período correspondente
            if (agendamento.periodo === 'manha') {
                clientesManha.push(itemCliente);
            } else {
                clientesTarde.push(itemCliente);
            }
        });
        
        // Montar HTML final
        if (clientesManha.length > 0) {
            htmlManha += '<div class="list-group">' + clientesManha.join('') + '</div>';
        } else {
            htmlManha += '<div class="alert alert-light">Nenhum cliente agendado para este período</div>';
        }
        
        if (clientesTarde.length > 0) {
            htmlTarde += '<div class="list-group">' + clientesTarde.join('') + '</div>';
        } else {
            htmlTarde += '<div class="alert alert-light">Nenhum cliente agendado para este período</div>';
        }
        
        // Atualizar container
        clientesContainer.innerHTML = htmlManha + htmlTarde;
    }
}

// Carregar dados do cliente
function carregarDadosCliente(clienteId) {
    console.log('Carregando dados do cliente:', clienteId);
    
    // Atualizar cliente atual
    clienteAtual = clienteId;
    
    // Obter dados do cliente
    const cliente = window.clientes[clienteId];
    if (!cliente) {
        showNotification('Erro', 'Cliente não encontrado', 'danger');
        return;
    }
    
    // Preencher campos do cliente
    document.getElementById('cliente-id').value = clienteId;
    document.getElementById('nome-cliente').value = cliente.nome || '';
    document.getElementById('empresa-cliente').value = cliente.empresa || '';
    document.getElementById('telefone-cliente').value = cliente.telefone || '';
    document.getElementById('email-cliente').value = cliente.email || '';
    document.getElementById('cnpj-cliente').value = cliente.cnpj || '';
    
    // Verificar se há prospecção para este cliente
    const prospeccao = window.prospeccoes[clienteId];
    
    // Limpar campos de prospecção
    document.getElementById('statusContato').value = '';
    document.getElementById('interesse').value = '';
    document.getElementById('produtosInteresse').value = '';
    document.getElementById('fornecedorAtual').value = '';
    document.getElementById('condicoesAtuais').value = '';
    document.getElementById('probabilidade').value = '';
    document.getElementById('valorEstimado').value = '';
    document.getElementById('proximosPassos').value = '';
    document.getElementById('observacoes').value = '';
    
    // Preencher campos de prospecção se existir
    if (prospeccao) {
        document.getElementById('statusContato').value = prospeccao.statusContato || '';
        document.getElementById('interesse').value = prospeccao.interesse || '';
        document.getElementById('produtosInteresse').value = prospeccao.produtosInteresse || '';
        document.getElementById('fornecedorAtual').value = prospeccao.fornecedorAtual || '';
        document.getElementById('condicoesAtuais').value = prospeccao.condicoesAtuais || '';
        document.getElementById('probabilidade').value = prospeccao.probabilidade || '';
        document.getElementById('valorEstimado').value = prospeccao.valorEstimado || '';
        document.getElementById('proximosPassos').value = prospeccao.proximosPassos || '';
        document.getElementById('observacoes').value = prospeccao.observacoes || '';
    }
    
    // Destacar formulário
    document.getElementById('prospeccao-form').classList.add('highlight-update');
    setTimeout(() => {
        document.getElementById('prospeccao-form').classList.remove('highlight-update');
    }, 2000);
}

// Salvar dados do formulário
function salvarDadosFormulario() {
    console.log('Salvando dados do formulário...');
    
    // Verificar se há cliente selecionado
    const clienteId = document.getElementById('cliente-id').value;
    if (!clienteId) {
        showNotification('Erro', 'Selecione um cliente antes de salvar', 'danger');
        return;
    }
    
    // Obter dados do formulário
    const statusContato = document.getElementById('statusContato').value;
    
    // Validar campos obrigatórios
    if (!statusContato) {
        showNotification('Erro', 'Preencha o status do contato', 'danger');
        return;
    }
    
    // Obter cliente
    const cliente = window.clientes[clienteId];
    if (!cliente) {
        showNotification('Erro', 'Cliente não encontrado', 'danger');
        return;
    }
    
    // Obter agendamento
    const agendamento = Object.values(window.agendamentos).find(a => a.id_cliente === clienteId);
    if (!agendamento) {
        showNotification('Erro', 'Agendamento não encontrado', 'danger');
        return;
    }
    
    // Criar objeto de prospecção
    const prospeccao = {
        id_cliente: clienteId,
        nome: cliente.nome,
        empresa: cliente.empresa,
        vendedor: vendedorAtual,
        dia_semana: diaSemanaAtual,
        periodo: agendamento.periodo,
        statusContato: statusContato,
        interesse: document.getElementById('interesse').value,
        produtosInteresse: document.getElementById('produtosInteresse').value,
        fornecedorAtual: document.getElementById('fornecedorAtual').value,
        condicoesAtuais: document.getElementById('condicoesAtuais').value,
        probabilidade: document.getElementById('probabilidade').value,
        valorEstimado: document.getElementById('valorEstimado').value,
        proximosPassos: document.getElementById('proximosPassos').value,
        observacoes: document.getElementById('observacoes').value
    };
    
    // Salvar prospecção
    if (window.salvarDadosProspeccao) {
        window.salvarDadosProspeccao(prospeccao)
            .then(result => {
                console.log('Prospecção salva com sucesso:', result);
                
                // Atualizar dados locais
                window.prospeccoes[clienteId] = prospeccao;
                
                // Atualizar UI
                carregarClientes();
            })
            .catch(error => {
                console.error('Erro ao salvar prospecção:', error);
                showNotification('Erro', 'Não foi possível salvar os dados. Tente novamente.', 'danger');
            });
    } else {
        console.error('Função salvarDadosProspeccao não está disponível');
        showNotification('Erro', 'Sistema de sincronização não está disponível', 'danger');
    }
}

// Mostrar notificação
function showNotification(title, message, type = 'info') {
    console.log(`Notificação (${type}):`, title, message);
    
    // Verificar se o container de notificações existe
    let notificationArea = document.getElementById('notification-area');
    
    // Se não existir, criar
    if (!notificationArea) {
        notificationArea = document.createElement('div');
        notificationArea.id = 'notification-area';
        notificationArea.style.position = 'fixed';
        notificationArea.style.top = '70px';
        notificationArea.style.right = '20px';
        notificationArea.style.width = '300px';
        notificationArea.style.zIndex = '1050';
        document.body.appendChild(notificationArea);
    }
    
    // Criar elemento de notificação
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.role = 'alert';
    
    // Adicionar conteúdo
    notification.innerHTML = `
        <strong>${title}</strong>
        <p>${message}</p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Adicionar ao container
    notificationArea.appendChild(notification);
    
    // Auto-fechar após 5 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Exportar funções para uso global
window.carregarClientes = carregarClientes;
window.carregarDadosCliente = carregarDadosCliente;
window.showNotification = showNotification;

// Inicializar aplicação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', inicializarApp);
