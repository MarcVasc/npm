// Aplicação de relatórios para o Sistema de Prospecção de Vendas
// Este arquivo gerencia a exibição e exportação de relatórios

// Variáveis globais
let dadosFiltrados = [];
let filtroVendedor = 'todos';
let filtroStatus = 'todos';
let filtroProbabilidade = 'todos';

// Função para inicializar a aplicação de relatórios
function inicializarRelatorios() {
    console.log('Inicializando aplicação de relatórios...');
    
    // Configurar eventos de botões
    configurarEventosBotoes();
    
    // Carregar dados iniciais
    setTimeout(() => {
        if (window.firebaseSync) {
            console.log('Firebase Sync disponível, carregando dados...');
        } else {
            console.warn('Firebase Sync não disponível, usando dados locais...');
            // Tentar carregar dados do servidor
            carregarDadosRelatorios();
        }
    }, 1000);
}

// Configurar eventos de botões
function configurarEventosBotoes() {
    // Botão de aplicar filtros
    document.getElementById('btn-aplicar-filtros').addEventListener('click', () => {
        aplicarFiltros();
    });
    
    // Botão de exportar Excel
    document.getElementById('btn-exportar-excel').addEventListener('click', () => {
        exportarExcel();
    });
    
    // Botão de atualizar dados
    document.getElementById('btn-atualizar-dados').addEventListener('click', () => {
        carregarDadosRelatorios();
    });
}

// Carregar dados dos relatórios
function carregarDadosRelatorios() {
    console.log('Carregando dados dos relatórios...');
    
    // Mostrar loading na tabela
    document.getElementById('tabela-relatorio-body').innerHTML = `
        <tr>
            <td colspan="9" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Carregando dados...</span>
                </div>
                <p class="mt-3">Carregando dados do relatório...</p>
            </td>
        </tr>
    `;
    
    // Verificar se temos prospecções
    if (!window.prospeccoes || Object.keys(window.prospeccoes).length === 0) {
        // Tentar carregar do servidor
        fetch('/api/prospeccoes')
            .then(response => response.json())
            .then(data => {
                window.prospeccoes = data;
                continuarCarregamento();
            })
            .catch(error => {
                console.error('Erro ao carregar prospecções:', error);
                document.getElementById('tabela-relatorio-body').innerHTML = `
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <div class="alert alert-danger">
                                <h5>Erro ao carregar dados</h5>
                                <p>Não foi possível carregar as prospecções. Tente novamente mais tarde.</p>
                            </div>
                        </td>
                    </tr>
                `;
            });
    } else {
        continuarCarregamento();
    }
    
    // Continuar carregamento após obter prospecções
    function continuarCarregamento() {
        // Verificar se temos clientes
        if (!window.clientes || Object.keys(window.clientes).length === 0) {
            // Tentar carregar do servidor
            fetch('/api/clientes')
                .then(response => response.json())
                .then(data => {
                    window.clientes = data;
                    processarDados();
                })
                .catch(error => {
                    console.error('Erro ao carregar clientes:', error);
                    // Continuar mesmo sem clientes
                    processarDados();
                });
        } else {
            processarDados();
        }
    }
    
    // Processar dados após carregar tudo
    function processarDados() {
        console.log('Processando dados para relatórios...');
        
        // Aplicar filtros atuais
        aplicarFiltros();
        
        // Destacar tabela
        document.getElementById('tabela-relatorio').classList.add('highlight');
        setTimeout(() => {
            document.getElementById('tabela-relatorio').classList.remove('highlight');
        }, 2000);
    }
}

// Aplicar filtros
function aplicarFiltros() {
    console.log('Aplicando filtros...');
    
    // Obter valores dos filtros
    filtroVendedor = document.getElementById('filtro-vendedor').value;
    filtroStatus = document.getElementById('filtro-status').value;
    filtroProbabilidade = document.getElementById('filtro-probabilidade').value;
    
    console.log('Filtros:', filtroVendedor, filtroStatus, filtroProbabilidade);
    
    // Filtrar dados
    dadosFiltrados = Object.values(window.prospeccoes || {}).filter(prospeccao => {
        // Filtro de vendedor
        if (filtroVendedor !== 'todos' && prospeccao.vendedor !== filtroVendedor) {
            return false;
        }
        
        // Filtro de status
        if (filtroStatus !== 'todos' && prospeccao.statusContato !== filtroStatus) {
            return false;
        }
        
        // Filtro de probabilidade
        if (filtroProbabilidade !== 'todos' && prospeccao.probabilidade !== filtroProbabilidade) {
            return false;
        }
        
        return true;
    });
    
    // Ordenar por data de salvamento (mais recente primeiro)
    dadosFiltrados.sort((a, b) => {
        if (!a.dataSalvamento) return 1;
        if (!b.dataSalvamento) return -1;
        return new Date(b.dataSalvamento) - new Date(a.dataSalvamento);
    });
    
    // Atualizar UI
    atualizarEstatisticas();
    atualizarGraficos();
    atualizarTabela();
}

// Atualizar estatísticas
function atualizarEstatisticas() {
    console.log('Atualizando estatísticas...');
    
    // Total de clientes
    const totalClientes = Object.keys(window.clientes || {}).length;
    document.getElementById('total-clientes').textContent = totalClientes;
    
    // Contatos realizados
    const contatosRealizados = Object.values(window.prospeccoes || {}).filter(p => p.statusContato === 'Realizado').length;
    document.getElementById('contatos-realizados').textContent = contatosRealizados;
    
    // Contatos pendentes
    const contatosPendentes = totalClientes - Object.keys(window.prospeccoes || {}).length;
    document.getElementById('contatos-pendentes').textContent = contatosPendentes;
    
    // Alta probabilidade
    const altaProbabilidade = Object.values(window.prospeccoes || {}).filter(p => p.probabilidade === 'Alta').length;
    document.getElementById('alta-probabilidade').textContent = altaProbabilidade;
}

// Atualizar gráficos
function atualizarGraficos() {
    console.log('Atualizando gráficos...');
    
    // Dados para gráfico de status
    const dadosStatus = {
        'Realizado': 0,
        'Não Atendeu': 0,
        'Número Inválido': 0,
        'Reagendado': 0,
        'Pendente': 0
    };
    
    // Dados para gráfico de vendedor
    const dadosVendedor = {
        'Vendedor 1': 0,
        'Vendedor 2': 0
    };
    
    // Contar ocorrências
    Object.values(window.prospeccoes || {}).forEach(prospeccao => {
        // Status
        if (prospeccao.statusContato) {
            dadosStatus[prospeccao.statusContato] = (dadosStatus[prospeccao.statusContato] || 0) + 1;
        } else {
            dadosStatus['Pendente'] = (dadosStatus['Pendente'] || 0) + 1;
        }
        
        // Vendedor
        if (prospeccao.vendedor) {
            dadosVendedor[prospeccao.vendedor] = (dadosVendedor[prospeccao.vendedor] || 0) + 1;
        }
    });
    
    // Criar gráfico de status
    criarGraficoStatus(dadosStatus);
    
    // Criar gráfico de vendedor
    criarGraficoVendedor(dadosVendedor);
}

// Criar gráfico de status
function criarGraficoStatus(dados) {
    // Obter canvas
    const canvas = document.getElementById('grafico-status');
    
    // Destruir gráfico existente se houver
    if (window.graficoStatus) {
        window.graficoStatus.destroy();
    }
    
    // Criar novo gráfico
    window.graficoStatus = new Chart(canvas, {
        type: 'pie',
        data: {
            labels: Object.keys(dados),
            datasets: [{
                data: Object.values(dados),
                backgroundColor: [
                    'rgba(40, 167, 69, 0.7)',  // Realizado - Verde
                    'rgba(255, 193, 7, 0.7)',  // Não Atendeu - Amarelo
                    'rgba(220, 53, 69, 0.7)',  // Número Inválido - Vermelho
                    'rgba(23, 162, 184, 0.7)', // Reagendado - Azul
                    'rgba(108, 117, 125, 0.7)' // Pendente - Cinza
                ],
                borderColor: [
                    'rgba(40, 167, 69, 1)',
                    'rgba(255, 193, 7, 1)',
                    'rgba(220, 53, 69, 1)',
                    'rgba(23, 162, 184, 1)',
                    'rgba(108, 117, 125, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Criar gráfico de vendedor
function criarGraficoVendedor(dados) {
    // Obter canvas
    const canvas = document.getElementById('grafico-vendedor');
    
    // Destruir gráfico existente se houver
    if (window.graficoVendedor) {
        window.graficoVendedor.destroy();
    }
    
    // Criar novo gráfico
    window.graficoVendedor = new Chart(canvas, {
        type: 'bar',
        data: {
            labels: Object.keys(dados),
            datasets: [{
                label: 'Contatos Realizados',
                data: Object.values(dados),
                backgroundColor: [
                    'rgba(13, 110, 253, 0.7)',  // Vendedor 1 - Azul
                    'rgba(102, 16, 242, 0.7)'   // Vendedor 2 - Roxo
                ],
                borderColor: [
                    'rgba(13, 110, 253, 1)',
                    'rgba(102, 16, 242, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Atualizar tabela
function atualizarTabela() {
    console.log('Atualizando tabela com', dadosFiltrados.length, 'registros');
    
    const tbody = document.getElementById('tabela-relatorio-body');
    
    // Verificar se há dados
    if (dadosFiltrados.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center py-4">
                    <div class="alert alert-info">
                        <h5>Nenhum dado encontrado</h5>
                        <p>Não foram encontrados dados com os filtros selecionados.</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    // Criar linhas da tabela
    let html = '';
    
    dadosFiltrados.forEach(prospeccao => {
        // Obter cliente
        const cliente = window.clientes[prospeccao.id_cliente] || {};
        
        // Determinar classes CSS baseadas no status e probabilidade
        let classeStatus = '';
        if (prospeccao.statusContato) {
            switch (prospeccao.statusContato) {
                case 'Realizado':
                    classeStatus = 'status-realizado';
                    break;
                case 'Não Atendeu':
                    classeStatus = 'status-nao-atendeu';
                    break;
                case 'Número Inválido':
                    classeStatus = 'status-invalido';
                    break;
                case 'Reagendado':
                    classeStatus = 'status-reagendado';
                    break;
            }
        }
        
        let classeProbabilidade = '';
        if (prospeccao.probabilidade) {
            switch (prospeccao.probabilidade) {
                case 'Alta':
                    classeProbabilidade = 'probabilidade-alta';
                    break;
                case 'Média':
                    classeProbabilidade = 'probabilidade-media';
                    break;
                case 'Baixa':
                    classeProbabilidade = 'probabilidade-baixa';
                    break;
            }
        }
        
        // Formatar data
        let dataFormatada = '';
        if (prospeccao.dataSalvamento) {
            const data = new Date(prospeccao.dataSalvamento);
            dataFormatada = data.toLocaleDateString('pt-BR') + ' ' + data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        }
        
        // Criar linha
        html += `
            <tr>
                <td>${cliente.nome || 'N/A'}</td>
                <td>${cliente.empresa || 'N/A'}</td>
                <td>${prospeccao.vendedor || 'N/A'}</td>
                <td class="${classeStatus}">${prospeccao.statusContato || 'Pendente'}</td>
                <td>${prospeccao.interesse || 'N/A'}</td>
                <td>${prospeccao.fornecedorAtual || 'N/A'}</td>
                <td class="${classeProbabilidade}">${prospeccao.probabilidade || 'N/A'}</td>
                <td>${prospeccao.valorEstimado || 'N/A'}</td>
                <td>${dataFormatada || 'N/A'}</td>
            </tr>
        `;
    });
    
    // Atualizar tbody
    tbody.innerHTML = html;
}

// Exportar Excel
function exportarExcel() {
    console.log('Exportando relatório para Excel...');
    
    if (window.exportarRelatorioExcel) {
        window.exportarRelatorioExcel();
    } else {
        // Fallback: redirecionar para a URL de exportação
        window.location.href = '/api/exportar/excel';
    }
}

// Mostrar notificação
function showNotification(title, message, type = 'info') {
    console.log(`Notificação (${type}):`, title, message);
    
    // Verificar se o container de notificações existe
    let notificationArea = document.getElementById('notification-area');
    
    // Se não existir, criar
    if (!notificationArea) {
        notificationArea = document.createElement('div');
        notificationArea.id = 'notification-area';
        notificationArea.style.position = 'fixed';
        notificationArea.style.top = '70px';
        notificationArea.style.right = '20px';
        notificationArea.style.width = '300px';
        notificationArea.style.zIndex = '1050';
        document.body.appendChild(notificationArea);
    }
    
    // Criar elemento de notificação
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show`;
    notification.role = 'alert';
    
    // Adicionar conteúdo
    notification.innerHTML = `
        <strong>${title}</strong>
        <p>${message}</p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Adicionar ao container
    notificationArea.appendChild(notification);
    
    // Auto-fechar após 5 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Exportar funções para uso global
window.carregarDadosRelatorios = carregarDadosRelatorios;
window.showNotification = showNotification;

// Inicializar aplicação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', inicializarRelatorios);
