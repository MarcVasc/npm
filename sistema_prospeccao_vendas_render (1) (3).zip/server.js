const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const firebase = require('firebase/app');
const { getDatabase, ref, set, get, onValue, push, update, remove } = require('firebase/database');
const { getAuth, signInAnonymously } = require('firebase/auth');
const ExcelJS = require('exceljs');
const multer = require('multer');
const xlsx = require('xlsx');
const path = require('path');
const firebaseConfig = require('./firebase-config');

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);
const database = getDatabase();
const auth = getAuth();

// Autenticar anonimamente para simplificar o uso
signInAnonymously(auth)
  .then(() => {
    console.log('Autenticado anonimamente com sucesso');
  })
  .catch((error) => {
    console.error('Erro na autenticação anônima:', error);
  });

// Configurar servidor Express
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(express.static('public'));

// Configurar multer para upload de arquivos
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Porta do servidor
const PORT = process.env.PORT || 3001;

// Rotas da API

// Rota para verificar status do servidor
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    sincronizacao: 'ativa'
  });
});

// Rota para obter todos os clientes
app.get('/api/clientes', async (req, res) => {
  try {
    const clientesRef = ref(database, 'clientes');
    const snapshot = await get(clientesRef);
    
    if (snapshot.exists()) {
      res.json(snapshot.val());
    } else {
      res.json({});
    }
  } catch (error) {
    console.error('Erro ao obter clientes:', error);
    res.status(500).json({ error: 'Erro ao obter clientes' });
  }
});

// Rota para obter todos os agendamentos
app.get('/api/agendamentos', async (req, res) => {
  try {
    const agendamentosRef = ref(database, 'agendamentos');
    const snapshot = await get(agendamentosRef);
    
    if (snapshot.exists()) {
      res.json(snapshot.val());
    } else {
      res.json({});
    }
  } catch (error) {
    console.error('Erro ao obter agendamentos:', error);
    res.status(500).json({ error: 'Erro ao obter agendamentos' });
  }
});

// Rota para obter todas as prospecções
app.get('/api/prospeccoes', async (req, res) => {
  try {
    const prospeccoesRef = ref(database, 'prospeccoes');
    const snapshot = await get(prospeccoesRef);
    
    if (snapshot.exists()) {
      res.json(snapshot.val());
    } else {
      res.json({});
    }
  } catch (error) {
    console.error('Erro ao obter prospecções:', error);
    res.status(500).json({ error: 'Erro ao obter prospecções' });
  }
});

// Rota para salvar uma prospecção
app.post('/api/prospeccoes', async (req, res) => {
  try {
    const { prospeccao, dispositivo } = req.body;
    
    if (!prospeccao || !prospeccao.id_cliente) {
      return res.status(400).json({ error: 'Dados de prospecção inválidos' });
    }
    
    // Adicionar timestamp e informações do dispositivo
    prospeccao.data_salvamento = new Date().toISOString();
    prospeccao.dispositivo = dispositivo || 'desconhecido';
    
    // Salvar prospecção no Firebase
    const prospeccoesRef = ref(database, `prospeccoes/${prospeccao.id_cliente}`);
    await set(prospeccoesRef, prospeccao);
    
    // Registrar operação de sincronização
    const sincronizacaoRef = ref(database, 'sincronizacao');
    const newSincRef = push(sincronizacaoRef);
    await set(newSincRef, {
      timestamp: prospeccao.data_salvamento,
      dispositivo: dispositivo || 'desconhecido',
      operacao: 'salvar',
      tabela: 'prospeccoes',
      registro_id: prospeccao.id_cliente
    });
    
    res.json({ 
      success: true, 
      message: 'Dados salvos e sincronizados com sucesso',
      timestamp: prospeccao.data_salvamento
    });
  } catch (error) {
    console.error('Erro ao salvar prospecção:', error);
    res.status(500).json({ error: 'Erro ao salvar prospecção' });
  }
});

// Rota para importar clientes de arquivo Excel
app.post('/api/importar/excel', upload.single('arquivo'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Nenhum arquivo enviado' });
    }
    
    // Ler arquivo Excel
    const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const dados = xlsx.utils.sheet_to_json(worksheet);
    
    if (!dados || dados.length === 0) {
      return res.status(400).json({ error: 'Arquivo Excel vazio ou inválido' });
    }
    
    // Processar clientes
    const clientes = dados.map((row, index) => {
      return {
        id_cliente: `cliente_${index + 1}`,
        nome: row.Nome || row.NOME || row.nome || '',
        empresa: row.Empresa || row.EMPRESA || row.empresa || '',
        telefone: row.Telefone || row.TELEFONE || row.telefone || '',
        email: row.Email || row.EMAIL || row.email || '',
        cnpj: row.CNPJ || row.cnpj || '',
        cidade: row.Cidade || row.CIDADE || row.cidade || '',
        estado: row.Estado || row.ESTADO || row.estado || '',
        segmento: row.Segmento || row.SEGMENTO || row.segmento || '',
        data_importacao: new Date().toISOString()
      };
    });
    
    // Dividir clientes entre vendedores e criar agendamentos
    const totalClientes = clientes.length;
    const clientesVendedor1 = clientes.slice(0, Math.ceil(totalClientes / 2));
    const clientesVendedor2 = clientes.slice(Math.ceil(totalClientes / 2));
    
    // Criar agendamentos
    const agendamentos = [];
    const diasSemana = ['segunda', 'terca', 'quarta', 'quinta', 'sexta'];
    const periodos = ['manha', 'tarde'];
    
    // Função para criar agendamentos para um vendedor
    const criarAgendamentos = (clientesVendedor, vendedor) => {
      let clienteIndex = 0;
      
      for (const dia of diasSemana) {
        for (const periodo of periodos) {
          // 5 clientes por período
          for (let i = 0; i < 5; i++) {
            if (clienteIndex < clientesVendedor.length) {
              const cliente = clientesVendedor[clienteIndex];
              
              agendamentos.push({
                id_agendamento: `${vendedor}_${dia}_${periodo}_${i + 1}`,
                id_cliente: cliente.id_cliente,
                vendedor: vendedor,
                dia_semana: dia,
                periodo: periodo,
                ordem: i + 1,
                data_agendamento: new Date().toISOString(),
                status: 'Pendente'
              });
              
              clienteIndex++;
            }
          }
        }
      }
    };
    
    // Criar agendamentos para ambos vendedores
    criarAgendamentos(clientesVendedor1, 'Vendedor 1');
    criarAgendamentos(clientesVendedor2, 'Vendedor 2');
    
    // Salvar clientes no Firebase
    const clientesRef = ref(database, 'clientes');
    const clientesObj = {};
    
    clientes.forEach(cliente => {
      clientesObj[cliente.id_cliente] = cliente;
    });
    
    await set(clientesRef, clientesObj);
    
    // Salvar agendamentos no Firebase
    const agendamentosRef = ref(database, 'agendamentos');
    const agendamentosObj = {};
    
    agendamentos.forEach(agendamento => {
      agendamentosObj[agendamento.id_agendamento] = agendamento;
    });
    
    await set(agendamentosRef, agendamentosObj);
    
    res.json({ 
      success: true, 
      message: `${clientes.length} clientes importados e agendados com sucesso`,
      clientes: clientes.length,
      agendamentos: agendamentos.length
    });
  } catch (error) {
    console.error('Erro ao importar arquivo Excel:', error);
    res.status(500).json({ error: 'Erro ao importar arquivo Excel' });
  }
});

// Rota para exportar relatórios em Excel
app.get('/api/exportar/excel', async (req, res) => {
  try {
    // Obter dados do Firebase
    const prospeccoesRef = ref(database, 'prospeccoes');
    const clientesRef = ref(database, 'clientes');
    
    const [prospeccoesSnapshot, clientesSnapshot] = await Promise.all([
      get(prospeccoesRef),
      get(clientesRef)
    ]);
    
    const prospeccoes = prospeccoesSnapshot.exists() ? prospeccoesSnapshot.val() : {};
    const clientes = clientesSnapshot.exists() ? clientesSnapshot.val() : {};
    
    // Criar workbook Excel
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Sistema de Prospecção de Vendas';
    workbook.lastModifiedBy = 'Sistema de Prospecção de Vendas';
    workbook.created = new Date();
    workbook.modified = new Date();
    
    // Criar planilha de relatório
    const worksheet = workbook.addWorksheet('Relatório de Prospecções', {
      properties: { tabColor: { argb: '4F81BD' } }
    });
    
    // Definir colunas
    worksheet.columns = [
      { header: 'ID Cliente', key: 'id_cliente', width: 15 },
      { header: 'Nome', key: 'nome', width: 25 },
      { header: 'Empresa', key: 'empresa', width: 25 },
      { header: 'Telefone', key: 'telefone', width: 15 },
      { header: 'Email', key: 'email', width: 25 },
      { header: 'Vendedor', key: 'vendedor', width: 15 },
      { header: 'Status do Contato', key: 'statusContato', width: 20 },
      { header: 'Interesse', key: 'interesse', width: 15 },
      { header: 'Produtos de Interesse', key: 'produtosInteresse', width: 30 },
      { header: 'Fornecedor Atual', key: 'fornecedorAtual', width: 20 },
      { header: 'Condições Atuais', key: 'condicoesAtuais', width: 25 },
      { header: 'Probabilidade', key: 'probabilidade', width: 15 },
      { header: 'Valor Estimado', key: 'valorEstimado', width: 15 },
      { header: 'Próximos Passos', key: 'proximosPassos', width: 30 },
      { header: 'Observações', key: 'observacoes', width: 30 },
      { header: 'Data Salvamento', key: 'dataSalvamento', width: 20 }
    ];
    
    // Estilizar cabeçalho
    worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFF' } };
    worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4F81BD' } };
    worksheet.getRow(1).alignment = { vertical: 'middle', horizontal: 'center' };
    
    // Adicionar dados
    const dados = [];
    
    Object.values(prospeccoes).forEach(prospeccao => {
      const cliente = clientes[prospeccao.id_cliente] || {};
      
      dados.push({
        id_cliente: prospeccao.id_cliente,
        nome: cliente.nome || '',
        empresa: cliente.empresa || '',
        telefone: cliente.telefone || '',
        email: cliente.email || '',
        vendedor: prospeccao.vendedor || '',
        statusContato: prospeccao.statusContato || '',
        interesse: prospeccao.interesse || '',
        produtosInteresse: prospeccao.produtosInteresse || '',
        fornecedorAtual: prospeccao.fornecedorAtual || '',
        condicoesAtuais: prospeccao.condicoesAtuais || '',
        probabilidade: prospeccao.probabilidade || '',
        valorEstimado: prospeccao.valorEstimado || '',
        proximosPassos: prospeccao.proximosPassos || '',
        observacoes: prospeccao.observacoes || '',
        dataSalvamento: prospeccao.dataSalvamento || ''
      });
    });
    
    // Adicionar linhas
    worksheet.addRows(dados);
    
    // Aplicar estilos condicionais
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber > 1) {
        // Alternar cores de fundo para facilitar leitura
        const fill = rowNumber % 2 === 0 
          ? { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' } }
          : { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF' } };
        
        row.eachCell((cell) => {
          cell.fill = fill;
          cell.border = {
            top: { style: 'thin', color: { argb: 'D3D3D3' } },
            left: { style: 'thin', color: { argb: 'D3D3D3' } },
            bottom: { style: 'thin', color: { argb: 'D3D3D3' } },
            right: { style: 'thin', color: { argb: 'D3D3D3' } }
          };
          
          // Colorir células de status
          if (cell._column.key === 'statusContato') {
            const status = cell.value;
            if (status === 'Realizado') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C6EFCE' } }; // Verde claro
            } else if (status === 'Não Atendeu') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEB9C' } }; // Amarelo claro
            } else if (status === 'Número Inválido') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC7CE' } }; // Vermelho claro
            } else if (status === 'Reagendado') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'B4C6E7' } }; // Azul claro
            }
          }
          
          // Colorir células de probabilidade
          if (cell._column.key === 'probabilidade') {
            const probabilidade = cell.value;
            if (probabilidade === 'Alta') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'C6EFCE' } }; // Verde claro
            } else if (probabilidade === 'Média') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEB9C' } }; // Amarelo claro
            } else if (probabilidade === 'Baixa') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFC7CE' } }; // Vermelho claro
            }
          }
        });
      }
    });
    
    // Congelar cabeçalho
    worksheet.views = [
      { state: 'frozen', xSplit: 0, ySplit: 1, activeCell: 'A2' }
    ];
    
    // Configurar resposta
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=Relatorio_Prospeccoes.xlsx');
    
    // Enviar arquivo
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error('Erro ao exportar relatório Excel:', error);
    res.status(500).json({ error: 'Erro ao exportar relatório Excel' });
  }
});

// Servir o frontend para qualquer outra rota
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Iniciar o servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando na porta ${PORT}`);
  console.log('Sincronização em tempo real ativada');
});
