# Manual de Uso - Sistema de Prospecção de Vendas

## Introdução

O Sistema de Prospecção de Vendas é uma ferramenta completa para gerenciar o processo de prospecção de clientes, permitindo que vendedores organizem seus contatos, registrem informações importantes e acompanhem o progresso das negociações. O sistema foi desenvolvido para funcionar em múltiplos dispositivos com sincronização em tempo real, garantindo que as informações estejam sempre atualizadas para todos os usuários.

## Características Principais

- **Divisão de clientes entre vendedores**: Os clientes são automaticamente divididos entre os vendedores (Vendedor 1 e Vendedor 2).
- **Agendamento semanal**: 5 clientes pela manhã e 5 à tarde para cada vendedor, distribuídos nos dias da semana.
- **Formulário completo de prospecção**: Campos para registro de todas as informações relevantes no contato com o cliente.
- **Sincronização em tempo real**: Alterações feitas em um dispositivo são automaticamente refletidas em todos os outros dispositivos conectados.
- **Funcionamento offline**: O sistema continua funcionando mesmo sem conexão, sincronizando os dados quando a conexão for restabelecida.
- **Relatórios detalhados**: Visualização e exportação de relatórios com filtros e gráficos.
- **Exportação para Excel**: Relatórios formatados com cores e estilos para facilitar a leitura.

## Requisitos do Sistema

- Navegador web moderno (Chrome, Firefox, Edge ou Safari)
- Conexão com a internet para sincronização entre dispositivos
- Arquivo Excel com a lista de clientes para importação inicial

## Instalação e Configuração

1. Acesse o sistema através da URL fornecida
2. Na primeira execução, será necessário importar a lista de clientes
3. O sistema estará pronto para uso após a importação

## Guia de Uso

### Tela Inicial

A tela inicial do sistema apresenta:

- **Seleção de vendedor**: Escolha entre Vendedor 1 e Vendedor 2
- **Seleção de dia da semana**: Escolha entre Segunda a Sexta
- **Lista de clientes agendados**: Divididos entre períodos da manhã e tarde
- **Formulário de prospecção**: Para registrar informações do contato

### Importação de Clientes

Para importar clientes para o sistema:

1. Na tela inicial, clique no botão "Importar" (visível quando não há clientes no sistema)
2. Selecione o arquivo Excel com a lista de clientes
3. Clique em "Importar" e aguarde a conclusão do processo
4. Os clientes serão automaticamente divididos entre os vendedores e agendados nos dias da semana

O arquivo Excel deve conter as seguintes colunas (não importa se estão em maiúsculas ou minúsculas):
- Nome
- Empresa
- Telefone
- Email
- CNPJ
- Cidade (opcional)
- Estado (opcional)
- Segmento (opcional)

### Navegação entre Vendedores e Dias

Para navegar entre vendedores e dias da semana:

1. Clique nos botões "Vendedor 1" ou "Vendedor 2" para alternar entre os vendedores
2. Clique nos botões dos dias da semana (Seg, Ter, Qua, Qui, Sex) para visualizar os clientes agendados em cada dia

### Registro de Informações de Prospecção

Para registrar informações de um cliente:

1. Selecione o cliente na lista de clientes agendados
2. Preencha os campos do formulário de prospecção:
   - **Status do Contato**: Realizado, Não Atendeu, Número Inválido ou Reagendado
   - **Interesse**: Alto, Médio, Baixo ou Nenhum
   - **Produtos de Interesse**: Quais produtos o cliente tem interesse
   - **Fornecedor Atual**: Quem é o fornecedor atual do cliente
   - **Condições Comerciais Atuais**: Preços, prazos, etc.
   - **Probabilidade de Fechamento**: Alta, Média ou Baixa
   - **Valor Estimado**: Valor estimado da venda
   - **Próximos Passos**: Ações a serem tomadas
   - **Observações**: Informações adicionais
3. Clique no botão "Salvar" para registrar as informações

### Relatórios

Para acessar os relatórios:

1. Clique no link "Relatórios" no menu superior
2. Utilize os filtros para refinar os dados:
   - **Vendedor**: Filtrar por vendedor
   - **Status do Contato**: Filtrar por status
   - **Probabilidade**: Filtrar por probabilidade
3. Clique em "Aplicar Filtros" para atualizar os dados
4. Visualize as estatísticas e gráficos
5. Para exportar os dados para Excel, clique no botão "Exportar Excel"

### Sincronização

O sistema sincroniza automaticamente os dados entre dispositivos. O status da sincronização é exibido no canto superior direito:

- **Online (verde)**: O sistema está conectado e sincronizando em tempo real
- **Offline (vermelho)**: O sistema está funcionando offline

Quando o sistema está offline:
1. Você pode continuar trabalhando normalmente
2. As alterações são salvas localmente
3. Quando a conexão for restabelecida, os dados serão sincronizados automaticamente

## Solução de Problemas

### O sistema não carrega

- Verifique sua conexão com a internet
- Tente recarregar a página
- Limpe o cache do navegador

### Não consigo importar clientes

- Verifique se o arquivo Excel está no formato correto
- Verifique se o arquivo contém as colunas necessárias
- Tente exportar o arquivo Excel em uma versão mais recente

### As alterações não estão sendo sincronizadas

- Verifique o status de sincronização no canto superior direito
- Se estiver offline, aguarde a conexão ser restabelecida
- Tente recarregar a página

### Os relatórios não mostram os dados corretos

- Verifique se os filtros estão configurados corretamente
- Clique em "Atualizar Dados" para recarregar os dados
- Verifique se há dados registrados para os filtros selecionados

## Considerações Finais

O Sistema de Prospecção de Vendas foi desenvolvido para facilitar o trabalho dos vendedores, permitindo um acompanhamento eficiente dos clientes e prospecções. A sincronização em tempo real garante que todos os usuários tenham acesso às informações mais atualizadas, mesmo quando trabalham em dispositivos diferentes.

Para qualquer dúvida ou suporte adicional, entre em contato com o administrador do sistema.
